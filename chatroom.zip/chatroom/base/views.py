from django.shortcuts import render
from .models import Room

# rooms = [
#     {"id":1,"name":"Learn Python with me"},
#     {"id":2,"name":"UI UX in 30 Days"},
#     {"id":3,"name":"Machine Learning"},
# ]

def home(request):
    rooms = Room.objects.all()
    print(rooms)
    context = {"rooms":rooms}
    return render(request,"home.html",context)

def room(request,pk):
    room = Room.objects.get(id=pk)
    return render(request,"room.html",{"room":room})